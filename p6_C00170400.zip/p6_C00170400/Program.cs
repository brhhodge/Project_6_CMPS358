﻿// Brian Hodge
// C00170400
// CMPS 358
// Project#6

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace p6_C00170400
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo wordsList1 = new FileInfo("words1.txt");
            FileInfo wordsList2 = new FileInfo("words2.txt");
            StreamReader readList1 = wordsList1.OpenText();
            StreamReader readList2 = wordsList2.OpenText();
            List<string> list1 = new List<string>();
            List<string> list2 = new List<string>();
            list1.Add(readList1.ToString());
            list2.Add(readList2.ToString());
            

        

            Console.WriteLine(readList1.ReadToEnd());   
        }
    }
}
